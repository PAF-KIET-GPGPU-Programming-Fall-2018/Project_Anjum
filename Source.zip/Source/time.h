#pragma once

#ifndef _TIMES_H
 
#include "times.h"
 
#endif
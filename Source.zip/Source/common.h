#pragma once
#ifndef __FILEH__
#define __FILEH__
#define N 8




#endif